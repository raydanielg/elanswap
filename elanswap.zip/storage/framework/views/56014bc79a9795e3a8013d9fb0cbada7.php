<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['disabled' => false, 'hasError' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['disabled' => false, 'hasError' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $baseClasses = 'block w-full rounded-md shadow-sm focus:ring-2 focus:ring-offset-1 transition duration-150 ease-in-out sm:text-sm';
    $stateClasses = $hasError 
        ? 'border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 focus:ring-red-500' 
        : 'border-gray-300 placeholder-gray-400 focus:border-primary-500 focus:ring-primary-500';
    $disabledClasses = $disabled ? 'bg-gray-100 cursor-not-allowed' : 'bg-white';
    $classes = "{$baseClasses} {$stateClasses} {$disabledClasses}";
?>

<input 
    <?php if($disabled): echo 'disabled'; endif; ?> 
    <?php echo e($attributes->merge(['class' => $classes])); ?>

>
<?php /**PATH E:\elanswap\elanswap\resources\views/components/text-input.blade.php ENDPATH**/ ?>