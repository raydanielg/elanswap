<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\PhoneAuthServiceProvider::class,
];
